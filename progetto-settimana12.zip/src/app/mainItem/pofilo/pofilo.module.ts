import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PofiloRoutingModule } from './pofilo-routing.module';
import { PofiloComponent } from './pofilo.component';
import {  MatTabsModule } from '@angular/material/tabs'


@NgModule({
  declarations: [
    PofiloComponent
  ],
  imports: [
    CommonModule,
    PofiloRoutingModule,
    MatTabsModule
  ]
})
export class PofiloModule { }
