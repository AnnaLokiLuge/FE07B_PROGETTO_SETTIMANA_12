import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PofiloComponent } from './pofilo.component';

const routes: Routes = [{ path: '', component: PofiloComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PofiloRoutingModule { }
