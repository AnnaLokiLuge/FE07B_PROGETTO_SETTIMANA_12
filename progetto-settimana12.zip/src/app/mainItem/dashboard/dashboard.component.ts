import { Component, OnInit } from "@angular/core";

@Component({
  selector: 'app-dashboard',
  template: `
    <app-navbar>
      <router-outlet></router-outlet>
    </app-navbar>
  `,
  styles: [
  ]
})
export class DashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
