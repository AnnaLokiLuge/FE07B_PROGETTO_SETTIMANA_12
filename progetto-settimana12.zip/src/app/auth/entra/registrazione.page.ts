import { Component, OnInit } from "@angular/core";
import { NgForm } from "@angular/forms";
import { Router } from "@angular/router";
import { AuthService } from "../auth.service";

@Component({
  template: `
    <div class="row justify-content-center">
      <div class="col">
        <div *ngIf="errorMessage" class="alert alert-danger" role="alert">
          {{errorMessage}}
        </div>
        <form #form="ngForm" (ngSubmit)="onsubmit(form)">
          <div class="form-group">
            <label for="name">Nome</label>
            <input
              ngModel
              name="name"
              class="form-control"
              type="text"
              id="name"
            />
          </div>
          <div class="form-group">
            <label for="cognome">Cognome</label>
            <input
              ngModel
              name="surname"
              class="form-control"
              type="text"
              id="cognome"
            />
          </div>
          <div class="form-group">
            <label for="email">Email</label>
            <input
              ngModel
              name="email"
              class="form-control"
              type="email"
              id="email"
            />
          </div>
          <div class="form-group">
            <label for="pass">Password</label>
            <input
              ngModel
              name="password"
              class="form-control"
              type="password"
              id="pass"
            />
          </div>
          <div class="d-flex justify-content-evenly">
          <button
            class="btn btn-primary mt-3"
            [disabled]="isLoading"
            type="submit"
          >
            Registrati
            <span
              *ngIf="isLoading"
              class="spinner-border spinner-border-sm"
              role="status"
              aria-hidden="true"
            ></span>
          </button>

         <button class="btn btn-primary mt-3 "[routerLink]="['/login']" routerLinkActive="active">Oppure Accedi</button>
         </div>
        </form>
      </div>
    </div>
  `,
  styles: [
    `
    :host{
        display: flex;
        flex-direction: column;
        justify-content: center;
        height: 100%;
        align-items: center;
        background-color: black;
        color:white;
      }
      form {
        max-width: 500px;
        width: 70rem;
        background-color: #383838d6;
        padding: 3rem;
      }

      `],
})
export class RegistrazionePage implements OnInit {
  isLoading = false;
  errorMessage = undefined
  constructor(private authSrv: AuthService, private router:Router) {}

  ngOnInit(): void {}

  async onsubmit(form: NgForm) {
    this.isLoading = true;
    console.log(form);
    try {
      await this.authSrv.signup(form.value).toPromise();
      form.reset();
      this.isLoading = false;
      this.errorMessage = undefined
      this.router.navigate(['/login'])
    } catch (error:any) {
      this.isLoading = false;
      this.errorMessage = error
      console.error(error);
    }
  }
}


