import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { AuthService } from "../auth.service";

@Component({
  template: `
    <div class="row justify-content-center">
      <div class="col">
      <div *ngIf="errorMessage" class="alert alert-danger" role="alert">
          {{errorMessage}}
        </div>
        <form  #form="ngForm" (ngSubmit)="onsubmit(form)" >
          <div class="form-group">
            <label for="email">Email</label>
            <input ngModel name="email" class="form-control" type="email" id="email" />
          </div>
          <div class="form-group">
            <label for="pass">Password</label>
            <input ngModel name="password" class="form-control" type="password" id="pass" />
          </div>
          <div class="d-flex justify-content-evenly">
          <button  class="btn btn-primary mt-3" [disabled]="isLoading" type="submit">Accedi
          <span
              *ngIf="isLoading"
              class="spinner-border spinner-border-sm"
              role="status"
              aria-hidden="true"
            ></span>
          </button>

         <button class="btn btn-primary mt-3 "[routerLink]="['/registrazione']" routerLinkActive="active">Registrati</button>
</div>
        </form>
      </div>
    </div>
  `,
  styles: [ `

:host{
        display: flex;
        flex-direction: column;
        justify-content: center;
        height: 100%;
        align-items: center;
        background-color: black;
        color:white;
      }
      form {
        max-width: 500px;
        width: 60rem;
        background-color: #383838d6;
        padding: 3rem;
      }
       `],
})
export class LoginPage implements OnInit {
  isLoading = false
  errorMessage = undefined
  constructor(private authSrv:AuthService,private router:Router) {}

  ngOnInit(): void {


  }

  async onsubmit(form:any){
    console.log(form)

    try {
      await this.authSrv.login(form.value).toPromise()
      form.reset()
      this.errorMessage=undefined
      this.router.navigate(['/'])

      // this.authSrv.user$.subscribe(val=>{
      //   console.log('user state da BehaviorSubject',val)
      // })
      // this.authSrv.user2$.subscribe(val=>{
      //   console.log('user state Subject',val)
      // })
    } catch (error:any) {
      this.errorMessage = error
      console.error(error)
      alert('Dati inseriti non corretti')
    }
  }
}
