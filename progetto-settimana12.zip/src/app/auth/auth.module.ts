import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoginPage } from './entra/login.page';
import { RegistrazionePage } from './entra/registrazione.page';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { TokenInterceptor } from './entra/token.interceptor';
import { AppRoutingModule } from './auth-routing.module';

import {MatFormFieldModule } from '@angular/material/form-field';
import { MatCardModule } from '@angular/material/card';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { FlexLayoutModule } from '@angular/flex-layout';

// PROBABILMENTE VANNO TOLTE TUTTE LE COSE DI MATERIALS



@NgModule({
  declarations: [
    LoginPage,
    RegistrazionePage,
  ],
  imports: [
    CommonModule,
    FlexLayoutModule,
        MatButtonModule,
        MatInputModule,
        MatCardModule,
        MatFormFieldModule,
        FormsModule,
        AppRoutingModule,

    RouterModule.forChild([
      {
        path:'login',
        component:LoginPage
      },
      {
        path:'registrazione',
        component:RegistrazionePage
      }
    ])
  ],
  providers:[
    {
      provide:HTTP_INTERCEPTORS,
      useClass:TokenInterceptor,
      multi:true
    }
  ],
})
export class AuthModule { }






// import { NgModule } from '@angular/core';
// import { CommonModule } from '@angular/common';

// import { AppRoutingModule } from './auth-routing.module';
// import { LoginPage } from './entra/login.page';
// import { RegistrazionePage } from './entra/registrazione.page';
// import {MatFormFieldModule } from '@angular/material/form-field';
// import { MatCardModule } from '@angular/material/card';
// import { MatInputModule } from '@angular/material/input';
// import { MatButtonModule } from '@angular/material/button';
// import { FlexLayoutModule } from '@angular/flex-layout';
// import { FormsModule } from '@angular/forms';
// import { HTTP_INTERCEPTORS } from '@angular/common/http';
// import { TokenInterceptor } from './entra/token.interceptor';


// @NgModule({
//   declarations: [
//     LoginPage,
//     RegistrazionePage
//   ],
//   imports: [
//     CommonModule,
//     AppRoutingModule,
//     FlexLayoutModule,
//     MatButtonModule,
//     MatInputModule,
//     MatCardModule,
//     MatFormFieldModule,
//     FormsModule
//   ],
//   providers: [
//     {
//       provide:HTTP_INTERCEPTORS,
//       useClass:TokenInterceptor,
//       multi:true
//     }
//   ]
// })
// export class AuthModule { }
