import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { RegistrazionePage } from './entra/registrazione.page';
import { LoginPage } from './entra/login.page';



const routes: Routes = [{


  path: 'login',
  component: LoginPage,
  },
  {
    path:'registrazione',
    component: RegistrazionePage,
  }
]

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
